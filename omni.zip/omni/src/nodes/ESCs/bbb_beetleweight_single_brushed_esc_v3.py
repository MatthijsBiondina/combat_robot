from abc import ABC

from src.utils.logger import get_logger

logger = get_logger()


class BBBBeetleweightSingleBrushedESC(ABC):
    def __init__(self):
        pass
