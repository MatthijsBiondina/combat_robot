import logging
import time
from typing import Optional, AnyStr, Type, Union

from cyclonedds.domain import DomainParticipant
from cyclonedds.core import Qos
from cyclonedds.idl import IdlStruct, IdlUnion
from cyclonedds.pub import DataWriter
from cyclonedds.qos import Policy
from cyclonedds.topic import Topic
from cyclonedds.util import duration

from src.cyclone.defaults import QOS
from src.idl.str_pod import StrPOD
from src.utils.logger import get_logger

a = get_logger()

logger = get_logger()


class Writer:
    def __init__(
        self,
        topic_name: AnyStr,
        data_type: Union[Type[IdlStruct], Type[IdlUnion]],
        qos: Qos = QOS,
    ):
        self.participant = DomainParticipant()
        self.topic = Topic(self.participant, topic_name, data_type, qos=qos)
        self.writer = DataWriter(self.participant, self.topic, qos=qos)

    def publish(self, msg: Union[IdlStruct, IdlUnion]):
        try:
            self.writer.write(msg)
        except Exception as e:
            logger.exception(f"Exception occurred while writing {type(msg)}.")


if __name__ == "__main__":
    writer = Writer("foo", StrPOD)
    for ii in range(int(1e6)):
        msg = f"{ii}"
        logger.log(logging.INFO, msg)
        pod = StrPOD(timestamp=time.time(), msg=f"foo {ii}")
        writer.publish(pod)

        time.sleep(1)
